<?php

$recipient = 'newrahulsinha@gmail.com';
if(isset($_POST['name']) || isset($_POST['email']) || isset($_POST['subject'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $subject = $_POST['subject'];
    $msg = $_POST['message'];
    
    if(isset($_POST['career'])){
        $date = date('d-m-Y');
		$ip = getenv("REMOTE_ADDR");
		$message = "---------------------------------------------------\n";
		$message.= "Date: " . $date . "\n";
		$message.= "Name: " . $name . "\n";
		$message.= "Email: " . $email . "\n";
		$message.= "Phone: " . $phone . "\n";
		$message.= "Subject: " . $subject . "\n";
		$message.= "Message: " . $msg . "\n";
		$message.= "---------------------------------------------------\n";
		$message.= "Client IP      : $ip\n";
		$subject = "Career Mail From: " . $name . "\n";
		$headers = "FROM: InfoLead <info@infolead.in>\r\n";
		$headers.= "MIME-Version: 1.0\n";

		mail($recipient, $subject, $message, $headers);
		die('1');
    }
    
    if(isset($_POST['contact'])){
    
        $date = date('d-m-Y');
		$ip = getenv("REMOTE_ADDR");
		$message = "---------------------------------------------------\n";
		$message.= "Date: " . $date . "\n";
		$message.= "Name: " . $name . "\n";
		$message.= "Email: " . $email . "\n";
		$message.= "Phone: " . $phone . "\n";
		$message.= "Subject: " . $subject . "\n";
		$message.= "Message: " . $msg . "\n";
		$message.= "---------------------------------------------------\n";
		$message.= "Client IP      : $ip\n";
		$subject = "Contact Mail From: " . $name . "\n";
		$headers = "FROM: InfoLead <info@infolead.in>\r\n";
		$headers.= "MIME-Version: 1.0\n";

		mail($recipient, $subject, $message, $headers);
		die('2');
    }
}
?>